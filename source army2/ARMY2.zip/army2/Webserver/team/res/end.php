<style>
    body {
    color: black;
    }
</style>
<?php
echo 
    "\n" . '<div id="footer">' .
    "\n" . ' <hr />' .
    "\n" . '<span>Đội Army II</span>' .
    "\n" . '</div>' .
    "\n" . '</body>' .
    "\n" . '</html>';
?>